package org.pentaho.commons.util.repository.type;

public enum TestEnum {

}
