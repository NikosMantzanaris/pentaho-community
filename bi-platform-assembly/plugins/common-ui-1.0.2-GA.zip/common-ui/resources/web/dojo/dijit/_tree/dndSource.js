define("dijit/_tree/dndSource", ["dojo", "dijit", "dijit/tree/dndSource"], function(dojo, dijit) {

// TODO: remove this file in 2.0
dojo.deprecated("dijit._tree.dndSource has been moved to dijit.tree.dndSource, use that instead", "", "2.0");

dijit._tree.dndSource = dijit.tree.dndSource;


return dijit._tree.dndSource;
});
