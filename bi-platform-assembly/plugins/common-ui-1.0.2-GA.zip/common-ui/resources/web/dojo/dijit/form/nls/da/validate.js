define(
//begin v1.x content
({
	invalidMessage: "Den angivne værdi er ikke gyldig.",
	missingMessage: "Værdien er påkrævet.",
	rangeMessage: "Værdien er uden for intervallet."
})
//end v1.x content
);
