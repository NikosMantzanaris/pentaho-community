define(
//begin v1.x content
({
		previousMessage: "Предыдущие варианты",
		nextMessage: "Следующие варианты"
})
//end v1.x content
);
