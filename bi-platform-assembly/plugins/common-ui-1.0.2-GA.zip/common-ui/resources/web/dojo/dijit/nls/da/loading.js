define(
//begin v1.x content
({
	loadingState: "Indlæser...",
	errorState: "Der er opstået en fejl"
})
//end v1.x content
);
