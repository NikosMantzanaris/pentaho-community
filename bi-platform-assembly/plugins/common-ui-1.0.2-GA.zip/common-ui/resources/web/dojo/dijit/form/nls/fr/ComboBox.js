define(
//begin v1.x content
({
		previousMessage: "Choix précédents",
		nextMessage: "Plus de choix"
})
//end v1.x content
);
