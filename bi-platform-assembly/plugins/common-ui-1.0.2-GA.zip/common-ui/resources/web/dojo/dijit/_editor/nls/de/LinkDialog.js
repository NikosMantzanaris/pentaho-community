define(
//begin v1.x content
({
	createLinkTitle: "Linkeigenschaften",
	insertImageTitle: "Grafikeigenschaften",
	url: "URL:",
	text: "Beschreibung:",
	target: "Ziel:",
	set: "Festlegen",
	currentWindow: "Aktuelles Fenster",
	parentWindow: "Übergeordnetes Fenster",
	topWindow: "Aktives Fenster",
	newWindow: "Neues Fenster"
})

//end v1.x content
);
