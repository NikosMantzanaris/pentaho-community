define(
//begin v1.x content
({
	invalidMessage: "Η τιμή που καταχωρήσατε δεν είναι έγκυρη.",
	missingMessage: "Η τιμή αυτή πρέπει απαραίτητα να καθοριστεί.",
	rangeMessage: "Η τιμή αυτή δεν ανήκει στο εύρος έγκυρων τιμών."
})
//end v1.x content
);
