define(
//begin v1.x content
({
	loadingState: "Ładowanie...",
	errorState: "Niestety, wystąpił błąd"
})
//end v1.x content
);
