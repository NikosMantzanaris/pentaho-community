define("dijit/form/MappedTextBox", ["dojo", "dijit", "dijit/form/ValidationTextBox"], function(dojo, dijit) {



return dijit.form.MappedTextBox;
});
