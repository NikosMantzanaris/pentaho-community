define(
//begin v1.x content
({
	loadingState: "ロード中...",
	errorState: "エラーが発生しました。"
})
//end v1.x content
);
