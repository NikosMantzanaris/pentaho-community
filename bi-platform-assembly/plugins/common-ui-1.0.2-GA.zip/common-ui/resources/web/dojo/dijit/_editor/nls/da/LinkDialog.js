define(
//begin v1.x content
({
	createLinkTitle: "Linkegenskaber",
	insertImageTitle: "Billedegenskaber",
	url: "URL:",
	text: "Beskrivelse:",
	target: "Mål:",
	set: "Definér",
	currentWindow: "Aktuelt vindue",
	parentWindow: "Overordnet vindue",
	topWindow: "Øverste vindue",
	newWindow: "Nyt vindue"
})

//end v1.x content
);
