define(
//begin v1.x content
({
		previousMessage: "Alegeri anterioare",
		nextMessage: "Mai multe alegeri"
})

//end v1.x content
);
