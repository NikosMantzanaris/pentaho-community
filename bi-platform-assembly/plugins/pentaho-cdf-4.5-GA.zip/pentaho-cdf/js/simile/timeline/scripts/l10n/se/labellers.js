﻿/*==================================================
 *  Localization of labellers.js
 *==================================================
 */

Timeline.GregorianDateLabeller.monthNames["se"] = [
    "Jan", "Feb", "Mar", "Apr", "Maj", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dec"
];

Timeline.GregorianDateLabeller.dayNames["se"] = [
    "Sön", "Mån", "Tis", "Ons", "Tors", "Fre", "Lör"
];
