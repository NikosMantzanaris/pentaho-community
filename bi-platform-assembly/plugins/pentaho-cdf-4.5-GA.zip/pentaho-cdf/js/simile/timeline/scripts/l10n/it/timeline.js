/*==================================================
 *  Common localization strings
 *==================================================
 */

Timeline.strings["it"] = {
    wikiLinkLabel:  "Discuti"
};

