/*
 * This program is free software; you can redistribute it and/or modify it under the 
 * terms of the GNU Lesser General Public License, version 2.1 as published by the Free Software 
 * Foundation.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this 
 * program; if not, you can obtain a copy at http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html 
 * or from the Free Software Foundation, Inc., 
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 *
 * Copyright 2008 - 2009 Pentaho Corporation.  All rights reserved.
 *
 *
 * @created June 27, 2008
 * @author Angelo Rodriguez
 * 
 */
package org.pentaho.platform.web.http.context;

import java.io.File;

import org.pentaho.platform.web.http.PentahoHttpSessionHelper;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.web.context.support.XmlWebApplicationContext;

/**
 * Overrides <code>getResourceByPath</code> so that relative paths are relative to the Pentaho solution repository's 
 * system directory instead of being relative to <code>WEB-INF</code>.
 * 
 * @author mlowery
 */
public class PentahoSolutionSpringApplicationContext extends XmlWebApplicationContext {

  protected Resource getResourceByPath(String path) {
    Resource resource = null;
    String solutionPath = PentahoHttpSessionHelper.getSolutionPath(getServletContext());
    if (solutionPath != null) {
      File file = new File(solutionPath + File.separator + "system" + File.separator + path);
      if (file.exists()) {
        resource = new FileSystemResource(file);
      }
    }
    if (resource == null) {
      resource = super.getResourceByPath(path);
    }
    return resource;
  }

}
